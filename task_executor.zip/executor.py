"""
Executor Module for Task Execution Engine

This module defines the Executor class which reads structured task JSON input,
validates it, and performs the corresponding actions by calling mock APIs.
It logs each step to a file and supports CLI execution with input JSON.

Author: Yousef Mohamed Saied
"""

import os
import logging
import requests
import sys
import json
from schemas import TaskInput

# Ensure logs directory exists
os.makedirs("logs", exist_ok=True)

# Configure logging to file with timestamped messages
logging.basicConfig(filename='logs/execution.log', level=logging.INFO, format='%(asctime)s - %(message)s')

class Executor:
    def __init__(self):
        self.api_routes = {
            "generate_po": "http://dev2.api/purchase_order",
            "update_balance": "http://dev2.api/update_balance"
        }

    def run(self, task_data: dict) -> dict:
        try:
            task = TaskInput(**task_data)
        except Exception as e:
            logging.error(f"Invalid input: {e}")
            return {"status": "failure", "reason": str(e)}

        if task.action == "generate_po":
            return self.generate_po(task)
        elif task.action == "update_balance":
            return self.update_balance(task)
        else:
            logging.error(f"Unknown action: {task.action}")
            return {"status": "failure", "reason": "Unknown action"}

    def generate_po(self, task: TaskInput) -> dict:
        payload = {
            "vendor": task.vendor,
            "items": [item.dict() for item in task.items]
        }
        try:
            result = {"status": "success", "po_id": "PO-2201"}  # Mocked
            logging.info(f"PO created for {task.vendor} - ID: {result.get('po_id')}")
            return {"status": "success", "po_id": result.get("po_id")}
        except Exception as e:
            logging.error(f"PO generation failed: {e}")
            return {"status": "failure", "reason": str(e)}

    def update_balance(self, task: TaskInput) -> dict:
        try:
            logging.info("Balance updated successfully")
            return {"status": "success"}
        except Exception as e:
            logging.error(f"Balance update failed: {e}")
            return {"status": "failure", "reason": str(e)}

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python executor.py <input_file.json>")
        sys.exit(1)

    input_file = sys.argv[1]
    try:
        with open(input_file, 'r') as f:
            task_data = json.load(f)
    except Exception as e:
        print(f"Error reading input file: {e}")
        sys.exit(1)

    executor = Executor()
    result = executor.run(task_data)
    print(json.dumps(result, indent=2))
