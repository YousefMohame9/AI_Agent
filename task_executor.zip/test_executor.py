"""
Test Script for Executor

Runs unit-like tests on the Executor class using sample task inputs.

Author: Yousef Mohamed Saied
"""

from executor import Executor

executor = Executor()

def test_generate_po():
    task = {
        "action": "generate_po",
        "vendor": "Dell",
        "items": [{"name": "Laptop", "qty": 5}]
    }
    result = executor.run(task)
    print("Generate PO:", result)

def test_invalid_action():
    task = {"action": "fly_to_mars"}
    result = executor.run(task)
    print("Invalid Action:", result)

def test_invalid_input():
    task = {"action": "generate_po", "vendor": "Dell", "items": "not a list"}
    result = executor.run(task)
    print("Invalid Input:", result)

test_generate_po()
test_invalid_action()
test_invalid_input()
