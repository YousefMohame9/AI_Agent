"""
Schemas Module

Defines the data structure of the input task JSON using Pydantic for validation.

Author: Yousef Mohamed Saied
"""

from pydantic import BaseModel
from typing import List, Optional

class Item(BaseModel):
    name: str
    qty: int

class TaskInput(BaseModel):
    action: str
    vendor: Optional[str]
    items: Optional[List[Item]]
